package com.example.Expense_tracker_backend.service;

import com.example.Expense_tracker_backend.model.Expense;
import com.example.Expense_tracker_backend.repository.ExpenseRepository;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ExpenseService {
    private final ExpenseRepository expenseRepository;

    public ExpenseService(ExpenseRepository expenseRepository) {
        this.expenseRepository = expenseRepository;
    }

    public List<Expense> getAllExpenses() {
        return expenseRepository.findAll(Sort.by(Sort.Direction.DESC, "createdAt"));
    }

    public Expense addExpense(Expense expense) {
        expense.setCreatedAt(LocalDateTime.now());
        expense.setUpdatedAt(LocalDateTime.now());
        return expenseRepository.save(expense);
    }

    public Expense updateExpense(Long id, Expense updatedExpense) {
        Expense expense = expenseRepository.findById(id).orElse(null);
        if (expense != null) {
            updatedExpense.setId(id);
            updatedExpense.setCreatedAt(expense.getCreatedAt());
            updatedExpense.setUpdatedAt(LocalDateTime.now());
            return expenseRepository.save(updatedExpense);
        }
        return null;
    }

    public void deleteExpense(Long id) {
        expenseRepository.deleteById(id);
    }
}

