package com.example.Expense_tracker_backend.controller;
import com.example.Expense_tracker_backend.model.Expense;
import com.example.Expense_tracker_backend.service.ExpenseService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
    @RequestMapping("/api/expenses")
    public class ExpenseController {
        private final ExpenseService expenseService;

        public ExpenseController(ExpenseService expenseService) {
            this.expenseService = expenseService;
        }

        @GetMapping
        public ResponseEntity<List<Expense>> getAllExpenses() {
            return ResponseEntity.ok(expenseService.getAllExpenses());
        }

        @PostMapping
        public ResponseEntity<Expense> addExpense(@RequestBody Expense expense) {
            return ResponseEntity.ok(expenseService.addExpense(expense));
        }

        @PutMapping("/{id}")
        public ResponseEntity<Expense> updateExpense(@PathVariable Long id, @RequestBody Expense expense) {
            Expense updatedExpense = expenseService.updateExpense(id, expense);
            if (updatedExpense != null) {
                return ResponseEntity.ok(updatedExpense);
            }
            return ResponseEntity.notFound().build();
        }

        @DeleteMapping("/{id}")
        public ResponseEntity<Void> deleteExpense(@PathVariable Long id) {
            expenseService.deleteExpense(id);
            return ResponseEntity.noContent().build();
        }
    }
