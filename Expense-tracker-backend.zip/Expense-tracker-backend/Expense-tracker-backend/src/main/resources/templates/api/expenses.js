function showAddExpenseForm() {
    var addExpenseForm = document.getElementById("addExpenseForm");
    if (addExpenseForm.style.display === "none") {
        addExpenseForm.style.display = "block";
    } else {
        addExpenseForm.style.display = "none";
    }
}
